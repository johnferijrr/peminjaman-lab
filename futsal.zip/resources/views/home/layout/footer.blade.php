<footer id="footer">
	<div class="container">
		<h3>{{$profil->nama_profil}}</h3>
		<div class="copyright">
			&copy; Website <strong><span>{{$profil->jenis_apk}} - {{$profil->nama_profil}}</span></strong>
		</div>
	</div>
</footer>