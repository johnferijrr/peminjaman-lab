
<?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',"$profil->nama_profil - $profil->jenis_apk"); ?>
<?php $__env->startSection('content'); ?>
<section id="hero" style="background-image: url(<?php echo e(asset('futsal-banner.jpg')); ?>);background-size: 100% 100%;background-repeat: no-repeat;">
  <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

    <div class="carousel-inner" role="listbox">

      <!-- Slide 1 -->
      <div class="carousel-item active">
        <div class="carousel-container">
          <div class="container">
            <h2 class="animate__animated animate__fadeInDown">Selamat Datang di <span>Web <br><?php echo e($profil->nama_profil); ?></span></h2>
            <!-- <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Panduan</a> -->
          </div>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Hero -->

<!-- ======= Why Us Section ======= -->
<section id="why-us" class="why-us">
  <div class="container">

    <div class="row no-gutters text-center">

      <div class="col-lg-3 col-md-6 content-item">
        <span>01</span>
        <h4>Registrasi</h4>
        <p>Lakukan Pendaftaran untuk User Baru</p>
      </div>

      <div class="col-lg-3 col-md-6 content-item">
        <span>02</span>
        <h4>Login</h4>
        <p>Lakukan Login dan Lakukan Penyewaan Sarana</p>
      </div>

      <div class="col-lg-3 col-md-6 content-item">
        <span>03</span>
        <h4>Pembayaran</h4>
        <p>Lakukan Pembayaran Penyewaan dengan meng-upload bukti Transfer sebelum Waktu Tenggat</p>
      </div>

      <div class="col-lg-3 col-md-6 content-item">
        <span>04</span>
        <h4>Proses Konfirmasi</h4>
        <p>Setelah pembayaran sudah di lakukan, tunggu Admin untuk Konfirmasi Pembayaran anda</p>
      </div>

    </div>

  </div>
</section><!-- End Why Us Section -->

<section id="team" class="team section-bg">
  <div class="container">

    <div class="section-title">
      <h2>Lapangan</h2>
    </div>

    <div class="row">
      <?php $__currentLoopData = $lapangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-3 col-md-6 align-items-stretch">
        <div class="member">
          <img src="<?php echo e(asset('gambar')); ?>/<?php echo e($lp->gambar); ?>" alt="">
          <h4><?php echo e($lp->nama_jenis); ?></h4>
          <span>
           <?php echo e(number_format($lp->harga,0,",",".")); ?> - <?php echo e($lp->nama_lap); ?>

         </span>
         <p>
          <a href="<?php echo e(route('boking',['id_lapangan'=>$lp->id_lapangan,'gambar'=>$lp->gambar])); ?>"><span class="badge" style="background: #f73859;">Klik untuk Sewa</span></a>
        </p>
        <div class="social">
          <a href="<?php echo e(route('visit',$lp->id_lapangan)); ?>" style="float: left;">Lihat Sarana</a>
          <!-- <a href="" style="float: right;">Cek Boking Sarana</a> -->
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

</div>
</section>

<!-- ======= Cta Section ======= -->
<section id="cta" class="cta">
  <div class="container">

    <div class="row">
      <div class="col-lg-9 text-center text-lg-start">
        <h3>Masuk di sini</h3>
        <p> Sudah punya Akun? kamu bisa Login untuk menuju ke Halaman Dashboard kamu masing-masing. <br> Klik <b>Login</b> di samping</p>
      </div>
      <div class="col-lg-3 cta-btn-container text-center">
        <a class="cta-btn align-middle" href="<?php echo e(route('login')); ?>">Login</a>
      </div>
    </div>

  </div>
</section><!-- End Cta Section -->

<!-- ======= Contact Section ======= -->
<section id="contact" class="contact">
  <div class="container">

    <div class="section-title">
      <h2>Lokasi</h2>
    </div>

    <div class="row">

      <div class="col-lg-12 d-flex align-items-stretch">
        <div class="info">
          <div class="address">
            <i class="bi bi-geo-alt"></i>
            <h4>Lokasi:</h4>
            <p>
              <?php
              $array = explode(PHP_EOL, $profil->lokasi);
              $total = count($array);
              foreach($array as $item) {
                echo "<span>". $item . "</span><br>";
              }
              ?>
            </p>
          </div>

          <div class="phone">
            <i class="bi bi-phone"></i>
            <h4>Telepon:</h4>
            <p><?php echo e($profil->no_profil); ?></p>
          </div>
          <iframe src="https://maps.google.com/maps?hl=en&amp;q=<?php echo e($profil->nama_profil); ?> <?php echo e($profil->lokasi); ?>+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
        </div>

      </div>

    </div>

  </div>
</section>
<?php $__env->stopSection(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('home/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Project Freelance\futsal\resources\views/home/beranda/index.blade.php ENDPATH**/ ?>