

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title',"$da->nama_lap"); ?>

<?php $__env->startSection('content'); ?><!-- End Header -->

<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Sarana Detail</h2>
      <ol>
        <li><a href="">Home</a></li>
        <li><a href="">Lihat Sarana</a></li>

      </ol>
    </div>

  </div>
</section><!-- End Breadcrumbs -->

<!-- ======= Portfolio Details Section ======= -->
<section id="portfolio-details" class="portfolio-details">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-8">
        <div class="portfolio-details-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide">
              <img src="<?php echo e(asset('gambar')); ?>/<?php echo e($da->gambar); ?>" alt="">
            </div>
            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
              <img src="<?php echo e(asset('image')); ?>/<?php echo e($img->filename); ?>" alt="">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="portfolio-info">
          <h3>Sarana Detail</h3>
          <ul>
            <li class="text mb-3" style="text-decoration: underline;"><center><h4><?php echo e($da->nama_jenis); ?></h4></center></li>
            <li><strong>Nama Sarana</strong>: <?php echo e($da->nama_lap); ?></li>
            <li><strong>Kegiatan</strong>: <?php echo e($da->kegiatan); ?></li>
            <li><strong>Harga</strong>: Rp <?php echo e(number_format($da->harga,0,",",".")); ?></li>
          </ul>
          <a href="<?php echo e(route('boking',['id_lapangan'=>$da->id_lapangan,'gambar'=>$da->gambar])); ?>" class="btn btn-danger btn-sm">Sewa</a>
        </div>
        <div class="portfolio-description">
          <h2>Keterangan/Detail Sarana</h2>
          <p>
            <?php
            $array = explode(PHP_EOL, $da->det_lapangan);
            $total = count($array);
            foreach($array as $item) {
              echo $item . "<br>";
            }
            ?>
          </p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Portfolio Details Section -->
<!-- ======= Contact Section ======= -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Project Freelance\futsal\resources\views/home/beranda/cek.blade.php ENDPATH**/ ?>