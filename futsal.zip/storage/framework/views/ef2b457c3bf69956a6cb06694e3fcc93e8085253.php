<footer id="footer">
	<div class="container">
		<h3><?php echo e($profil->nama_profil); ?></h3>
		<div class="copyright">
			&copy; Website <strong><span><?php echo e($profil->jenis_apk); ?> - <?php echo e($profil->nama_profil); ?></span></strong>
		</div>
	</div>
</footer><?php /**PATH E:\xampp\htdocs\Project Freelance\futsal\resources\views/home/layout/footer.blade.php ENDPATH**/ ?>