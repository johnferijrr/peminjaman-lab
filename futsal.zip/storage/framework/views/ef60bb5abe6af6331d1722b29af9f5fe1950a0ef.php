

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
                <h3>Dashboard Admin</h3>
            </div>
            <div class="page-content">
                <section class="row">
                    <div class="col-12 col-lg-9">
                        <div class="row">
                            <div class="col-6 col-lg-3 col-md-6">
                                <div class="card">
                                    <div class="card-body px-3 py-4-5">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="stats-icon purple">
                                                    <i class="iconly-boldShow"></i>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <h6 class="text-muted font-semibold">Data User</h6>
                                                <h6 class="font-extrabold mb-0"><?php echo e($user); ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-lg-3 col-md-6">
                                <div class="card">
                                    <div class="card-body px-3 py-4-5">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="stats-icon blue">
                                                    <i class="iconly-boldProfile"></i>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <h6 class="text-muted font-semibold">Kode Payment</h6>
                                                <h6 class="font-extrabold mb-0"><?php echo e($kode); ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-lg-3 col-md-6">
                                <div class="card">
                                    <div class="card-body px-3 py-4-5">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="stats-icon green">
                                                    <i class="iconly-boldAdd-User"></i>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <h6 class="text-muted font-semibold">Data Lapangan</h6>
                                                <h6 class="font-extrabold mb-0"><?php echo e($lapangan); ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-lg-3 col-md-6">
                                <div class="card">
                                    <div class="card-body px-3 py-4-5">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="stats-icon red">
                                                    <i class="iconly-boldBookmark"></i>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <h6 class="text-muted font-semibold">Laporan</h6>
                                                <!-- <h6 class="font-extrabold mb-0">112</h6> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-12 col-xl-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4>Form Penyewaan</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-lg">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Detail</th>
                                                        <th>Status Penyewaan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="col-3">
                                                            <div class="d-flex align-items-center">
                                                                <div class="avatar avatar-md">
                                                                    <?php if($dt->jenis_kelamin=="Laki-Laki"): ?>
                                                                    <img src="<?php echo e(asset('template/dist/assets/images/faces/2.jpg')); ?>">
                                                                    <?php endif; ?>
                                                                    <?php if($dt->jenis_kelamin=="Perempuan"): ?>
                                                                    <img src="<?php echo e(asset('template/dist/assets/images/faces/5.jpg')); ?>">
                                                                    <?php endif; ?>
                                                                </div>
                                                                <p class="font-bold ms-3 mb-0"><?php echo e($dt->name); ?></p>
                                                            </div>
                                                        </td>
                                                        <td class="col-auto">
                                                            <p class=" mb-0"><?php echo e($dt->nama_lap); ?> - <?php echo e($dt->nama_jenis); ?></p>
                                                            <p class=" mb-0">Tanggal : <?php echo e($dt->tanggal); ?></p>
                                                            <p class=" mb-0">Jam Penyewaan : <?php echo e($dt->jam_mulai); ?> - <?php echo e($dt->jam_selesai); ?></p>
                                                        </td>
                                                        <td class="col-auto">
                                                            <p class=" mb-0">Keterangan : <?php echo e($dt->keterangan); ?></p>
                                                            <p class=" mb-0">Konfirmasi : <?php echo e($dt->konfirmasi); ?></p>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3">
                        <div class="card">
                            <div class="card-body py-4 px-5">
                                <div class="d-flex align-items-center">
                                    <div class="avatar avatar-xl">
                                        <img src="<?php echo e(asset('template/dist/assets/images/faces/2.jpg')); ?>" alt="Face 1">
                                    </div>
                                    <div class="ms-3 name">
                                        <h5 class="font-bold"><?php echo e(Auth::user()->name); ?></h5>
                                        <h6 class="text-muted mb-0"><?php echo e(Auth::user()->level); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4>Data Penyewa</h4>
                            </div>
                            <div class="card-content pb-4">
                                <?php $__currentLoopData = $alluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="recent-message d-flex px-4 py-3">
                                    <div class="avatar avatar-lg">
                                        <?php if($us->jenis_kelamin=="Laki-Laki"): ?>
                                        <img src="<?php echo e(asset('template/dist/assets/images/faces/1.jpg')); ?>">
                                        <?php endif; ?>
                                        <?php if($us->jenis_kelamin=="Perempuan"): ?>
                                        <img src="<?php echo e(asset('template/dist/assets/images/faces/5.jpg')); ?>">
                                        <?php endif; ?>
                                        <?php if($us->jenis_kelamin==NULL): ?>
                                        <img src="<?php echo e(asset('template/dist/assets/images/faces/8.jpg')); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="name ms-4">
                                        <h5 class="mb-1"><?php echo e($us->name); ?></h5>
                                        <h6 class="text-muted mb-0"><?php echo e($us->username); ?></h6>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="px-4">
                                    <a href="<?php echo e(route('user')); ?>" class='btn btn-block btn-xl btn-light-primary font-bold mt-3'>All Data User</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Project Freelance\futsal\resources\views/page/home/index.blade.php ENDPATH**/ ?>